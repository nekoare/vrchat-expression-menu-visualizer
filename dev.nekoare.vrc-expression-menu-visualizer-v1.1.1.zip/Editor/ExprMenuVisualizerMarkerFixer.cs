// ExprMenuVisualizerMarkerFixer removed per project policy.
// This tool previously attempted to auto-add/remove marker components and to remove missing-script slots.
// It has been intentionally disabled/removed because it was a workaround and not a correct fix for
// marker serialization/assembly issues. If you need assistance implementing deterministic
// marker assignment in conversion paths, update `VRCExpressionMenuVisualizer.cs` conversion logic instead.
