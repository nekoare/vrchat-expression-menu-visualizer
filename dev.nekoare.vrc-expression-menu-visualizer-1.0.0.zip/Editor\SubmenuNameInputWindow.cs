using UnityEngine;
using UnityEditor;

namespace VRCExpressionMenuVisualizer
{
    public class SubmenuNameInputWindow : EditorWindow
    {
        private string inputText = "";
        private string dialogTitle = "Enter Name";
        private string dialogMessage = "Please enter a name:";
        private System.Action<string> onComplete;
        private bool focusSet = false;

        public static string ShowDialog(string title, string message, string defaultValue)
        {
            var window = GetWindow<SubmenuNameInputWindow>(true, title, true);
            window.dialogTitle = title;
            window.dialogMessage = message;
            window.inputText = defaultValue ?? "";
            window.onComplete = null;
            window.minSize = new Vector2(300, 100);
            window.maxSize = new Vector2(300, 100);
            window.ShowModal();
            
            // Simple blocking approach for dialog
            string result = null;
            bool dialogClosed = false;
            
            window.onComplete = (text) => 
            {
                result = text;
                dialogClosed = true;
            };
            
            // Wait for dialog to close
            while (!dialogClosed && window != null)
            {
                System.Threading.Thread.Sleep(10);
            }
            
            return result;
        }

        private void OnGUI()
        {
            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField(dialogMessage, EditorStyles.wordWrappedLabel);
            EditorGUILayout.Space(5);
            
            // Set focus to text field
            GUI.SetNextControlName("InputField");
            string newText = EditorGUILayout.TextField(inputText);
            
            if (!focusSet)
            {
                GUI.FocusControl("InputField");
                focusSet = true;
            }
            
            if (newText != inputText)
            {
                inputText = newText;
            }
            
            EditorGUILayout.Space(10);
            
            GUILayout.BeginHorizontal();
            
            if (GUILayout.Button("OK") || (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Return))
            {
                onComplete?.Invoke(inputText);
                Close();
            }
            
            if (GUILayout.Button("Cancel") || (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape))
            {
                onComplete?.Invoke(null);
                Close();
            }
            
            GUILayout.EndHorizontal();
            
            if (Event.current.type == EventType.KeyDown && (Event.current.keyCode == KeyCode.Return || Event.current.keyCode == KeyCode.Escape))
            {
                Event.current.Use();
            }
        }
    }
}
